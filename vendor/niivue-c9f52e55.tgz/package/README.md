# NiiVue

NiiVue is a tool for visualizing volumes, meshes, and tractography streamlines commonly used in neuroimaging. The original NiiVue project evolved organically, resulting in tightly coupled model, view, and controller components. This repository refactors the codebase to improve maintainability and to support emerging technologies such as WebGPU.

Documentation: https://niivue.github.io/mono/docs/guide/

## Getting Started

### Prerequisites

- [Bun](https://bun.sh/)
- A browser with WebGPU support (Chrome, Firefox). Safari works if you have a recent MacOS (version 26) or iOS. Older browsers will fall back to the WebGL2 renderer.
- Slides (`NVSlide`) need `AbortSignal.any` (Chrome 116, Firefox 124, Safari 17.4); `@niivue/nv-ext-tile` DICOM-WSI indexing also needs resizable `ArrayBuffer`s (Chrome 111, Firefox 128, Safari 16.4) and says so when they are missing.

### Build Commands

```bash
bun install          # Install dependencies
bun run dev          # Hot-reload dev server
bun run build        # Library build to ./dist (published npm package), incl. dist/standalone
bun run deploy       # Production examples-site build to ./dist-examples (GitHub Pages)
bun run demo         # Build examples site and serve locally
bun run lint         # Biome check
bun run lint:fix     # Biome auto-fix
bun run typecheck    # TypeScript type checking (tsc --noEmit)
```

### Unused-code audit

From the monorepo root, run the pinned Knip 6.39.0 audit:

```bash
bunx nx run niivue:knip
bunx nx run niivue:knip:production
```

The normal audit includes tests, examples (including their worker), and standalone
scripts. The production configuration checks library sources without treating
examples or test consumers as usage; it retains Vite support for `import.meta.glob`.
Both protect exports from all published package entry points. These targets scope
reporting to `packages/niivue`; `bun run knip` at the root audits the whole monorepo.

This is a manual review tool, not a CI gate. It exits with status 1 while findings
remain, including deliberately deferred exports. An unused export is a candidate,
not permission to remove an API: check extension packages, external consumers,
public type signatures, and recent PRs before changing it. Production-only findings
may be helpers used by tests. The duplicate named/default export of
`NVCanvasViewportController` is intentional and remains visible in the report.
Do not use `--include-entry-exports` or broad ignores to make the report pass.

See [Knip getting started](https://knip.dev/overview/getting-started) and
[how Knip works](https://knip.dev/explanations/how-knip-works) for interpreting results.

### Perf instrumentation

The renderer carries `performance.mark`/`measure` instrumentation
(`src/view/NVPerfMarks.ts`) gated on a single runtime flag. Consumers:

- **App code:** `nv.perf.enabled = true`, then listen for the
  `perfFrame` event to receive `{ tag, cpuMs, submitMs, totalMs, phases }`
  per render. Tag user-driven frames via `nv.perf.tagFrame('myAction')`
  before mutating state.
- **Benchmark harness** at `examples/benchmark.html` flips the same
  flag and reads `consumeFrameStats()` plus the `niivue:render-*`
  PerformanceObserver entries.

When `enabled` is `false` every helper bails on its first line; cost
in production is one well-predicted branch per call site. See
`benchmarks/README.md` for the harness workflow.

### Development Workflows

- **`bun run dev`** — Serves the `examples/` pages from source with hot reloading at `localhost:5273`. The pages `import '../src/index.ts'` directly, so dev and the deployed build run the same files. On-demand sample data (DICOM-WSI) is downloaded into `public/` if missing.
- **`bun run demo`** — Builds the examples site to `dist-examples/` and serves it with `vite preview`. Use this to test the actual built output or before deploying to GitHub Pages.

## Usage

Add a `<canvas>` to your page and attach NiiVue to it:

```html
<canvas id="gl1"></canvas>
<script type="module">
  import NiiVue from '@niivue/niivue'

  const nv = new NiiVue()
  await nv.attachToCanvas(document.getElementById('gl1'))
  await nv.loadVolumes([{ url: '/volumes/mni152.nii.gz' }])
</script>
```

### Backend-specific distributions

By default, `@niivue/niivue` includes both backends and renders with WebGL2. Opt in to WebGPU with the `backend` option; if WebGPU is unavailable or fails to initialize, it falls back to WebGL2:

```js
import NiiVue from '@niivue/niivue'

const nv = new NiiVue() // WebGL2
const nvGpu = new NiiVue({ backend: 'webgpu' }) // WebGPU, WebGL2 fallback
```

You can also import backend-only builds to reduce package size:

```js
import NiiVueWebGPU from '@niivue/niivue/webgpu' // WebGPU-only
import NiiVueWebGL2 from '@niivue/niivue/webgl2' // WebGL2-only
```

In backend-only builds, selecting the missing backend throws an explicit error.

### Multi-viewer scenes

`@niivue/niivue/scene` exports `NvSceneController`, which lays out several NiiVue
instances in one container element (it creates their divs and canvases) and can
sync them. `@niivue/nvreact` and `@niivue/nv-web-component` are built on it.
The subpath is side-effect free, is not part of the root entry, and has no
standalone copy. Scene viewers use the universal `@niivue/niivue` build: in an
app built on `@niivue/niivue/webgpu` or `/webgl2` they are not `instanceof` that
backend-only `NiiVue` class, and they bring in the other backend's view code.

```js
import { NvSceneController } from '@niivue/niivue/scene'

const scene = new NvSceneController()
scene.setContainerElement(document.getElementById('viewers'))
scene.setLayout('1x2') // two viewers side by side
await scene.loadVolume(0, { url: '/volumes/mni152.nii.gz' })
```

### Without a bundler (standalone ES modules)

The entry points above import `cbor-x`, `gl-matrix` and `nifti-reader-js` by
bare name, which only a bundler (or an import map listing every
dependency) can resolve. For pages with no JavaScript toolchain, such as static
HTML reports or pages served by a small Python server, the package also ships a
self-contained build in `dist/standalone/`:

```
dist/standalone/
  niivue.js              # same API as @niivue/niivue (both backends)
  niivue.webgl2.js       # same API as @niivue/niivue/webgl2
  niivue.webgpu.js       # same API as @niivue/niivue/webgpu
  viewport.js            # same API as @niivue/niivue/viewport
  assets/fonts/index.js
  assets/matcaps/index.js
  chunks/                # shared code and lazily loaded chunks
```

Every dependency is bundled in, workers and images are inlined, and chunks
import each other by relative path, so the folder has no external references
and works from any base URL. Optional code stays in chunks that are fetched
only when used; a page showing a
NIfTI volume loads about 1.6 MB of JavaScript (about 0.5 MB gzipped). The build
fails if any bare import appears in the folder (`scripts/check-standalone.ts`).

`@niivue/nv-ext-tile` ships a matching `dist/standalone/` (`tiff.js`, `dicom.js`, `zarr.js`) that maps onto this folder with the same import map; see its README.

Copy the folder next to your page (here as `niivue/`) and map the package name
once:

```html
<script type="importmap">
  { "imports": { "@niivue/niivue": "./niivue/niivue.js" } }
</script>
<canvas id="gl1"></canvas>
<script type="module">
  import NiiVue from '@niivue/niivue'

  const nv = new NiiVue()
  await nv.attachToCanvas(document.getElementById('gl1'))
  await nv.loadVolumes([{ url: './mni152.nii.gz' }])
</script>
```

The import map is optional; `import NiiVue from './niivue/niivue.js'` works
too. Load only one copy of NiiVue per page: the standalone folder and a bundled
copy are separate module instances.

To vendor a pinned release without Node, download the npm tarball, check it
against the registry's `dist.integrity`, and copy the folder out:

```bash
VERSION=1.0.0-rc.45
curl -sO "https://registry.npmjs.org/@niivue/niivue/-/niivue-$VERSION.tgz"
curl -s "https://registry.npmjs.org/@niivue/niivue/$VERSION" # read dist.integrity
echo "sha512-$(openssl dgst -sha512 -binary "niivue-$VERSION.tgz" | openssl base64 -A)"
tar -xzf "niivue-$VERSION.tgz" package/dist/standalone
cp -R package/dist/standalone ./niivue
```

Or point the import map at a CDN copy of the same folder:

```html
<script type="importmap">
  {
    "imports": {
      "@niivue/niivue": "https://cdn.jsdelivr.net/npm/@niivue/niivue@1.0.0-rc.45/dist/standalone/niivue.js"
    }
  }
</script>
```

Node tools that need the folder's location can resolve it through the package
exports: `import.meta.resolve('@niivue/niivue/standalone')` returns the URL of
`dist/standalone/niivue.js`.

`bun run build` produces the folder (`bun run build:standalone` rebuilds just
this part). To try it locally, run `bun run examples:standalone` after a build
and open http://localhost:5403/. That serves `examples/standalone/index.html`
with a plain static server, the built folder as `niivue/`, and the sample
volumes, with no Vite in between.

### Load a mesh

```js
await nv.loadMeshes([{ url: '/meshes/brain.mz3' }])
```

### AFNI tractography

Binary `.niml.tract` files load through `loadMeshes` or by dropping them onto
any viewer with drag-and-drop enabled (for example `examples/tract.html`).
Little- and big-endian records are supported; text/base64 NIML is not.
Coordinates are converted from AFNI RAI to RAS mm. Bundle IDs are available
for coloring with `tractOptions: { colorBy: 'dps:tract' }`.

### Signals (physio and spectroscopy)

Alongside spatial volumes and meshes, NiiVue can load **signals** — a third,
non-spatial data class shown as 2-D line plots rather than slices. Two kinds are
supported: `physio` (BIDS time-series TSV) and `spectroscopy` (NIfTI-MRS complex
FID). Sibling `.json` sidecars are fetched automatically for axis metadata
(sampling rate / StartTime for physio, SpectrometerFrequency / ResonantNucleus
for spectroscopy).

```js
// BIDS physio (auto-fetches the sibling .json sidecar)
await nv.loadSignals([{ url: '/signals/recording_physio.tsv.gz' }])

// NIfTI-MRS spectroscopy; setSignal drives the on-demand FFT + ppm windowing
await nv.loadSignals([{ url: '/signals/svs_se_30.nii.gz' }])
nv.setSignal(0, { display: { average: true, mode: 'real', ppmRange: [1.9, 3.3] } })
```

NIfTI files are routed to the signal loader when they have no spatial extent
(dim1-3 == 1, dim4 > 1); pass `asSignal` to override. MRS sidecar/header fields do
**not** affect routing — a spatial spectroscopic image (MRSI/CSI) carries them too,
so it stays on the volume path.

A physio signal can be associated with a 4D volume by passing `attachToId` (the
volume's id). The graph then shows the crosshair BOLD time-course together with
each physio trace at its native sampling rate on a shared time axis, clamped to
the imaging window; clicking the graph scrubs the volume to the nearest frame.

A dense signal graph can be panned and zoomed via on-graph buttons (the view
follows the cursor on wheel/frame steps) or the controller API (`graphZoom`,
`graphPan`); `graphLineWidth` / `graphLineAlpha` tune trace thickness and opacity
for overlapping series, and `graphShowVolumeTimecourse` toggles the BOLD trace.
Missing physio samples are left as gaps and marked with a short tick along the
bottom axis (the "missing-data rug").

Signals can carry **annotations** — text labels anchored to a position in the
graph's own data units (e.g. ppm for spectroscopy). They translate as the x-axis
window is panned/zoomed and are hidden when out of range. A `y` of `-Infinity` or
`+Infinity` pins the label to the bottom or top of the plot. Annotations render on
the signal graph (spectrum / physio plot); they are not currently drawn on the
volume+physio association time-course view.

```js
// Label metabolite peaks pinned to the bottom of the spectrum
await nv.loadSignals([{
  url: '/signals/svs_se_30.nii.gz',
  annotations: [
    { text: 'NAA', x: 2.0, y: -Infinity },
    { text: 'Cr',  x: 3.0, y: -Infinity },
    { text: 'Cho', x: 3.2, y: -Infinity },
  ],
}])
nv.setSignal(0, { annotations: [/* replace the full set */] })
```

See `examples/svs.html` (spectroscopy, with NAA/Cr/Cho annotations and a scene
selector pairing the spectrum with the participant's T2w and an outline-shaded
"voxel" marker at the sampling location), `examples/physio.html` (physio), and
`examples/physio.bold.html` (a task-fMRI run with per-trace fMRI/respiratory/
cardiac toggles, on-graph pan/zoom, and a volume+physio association graph) for
interactive demos.

#### Spatial spectroscopic imaging (MRSI/CSI)

A complex 4-D NIfTI-MRS volume (dim1-3 = space, dim4 = FID) stays on the volume
path and is driven by the core `MrsScene` controller: it loads an anatomy
reference plus the MRSI grid, shows the crosshair-voxel spectrum (which tracks
the crosshair like the FSLeyes MRS plugin), and generates ppm-band metabolite
maps. See `examples/mrsi.html`. The spectral transforms and the `MrsScene`
controller are ported from
[fsleyes-plugin-mrs](https://git.fmrib.ox.ac.uk/fsl/fsleyes/fsleyes-plugin-mrs)
(BSD-3-Clause); see `PORTING.md` for the function-by-function provenance map.

### Change slice type and colormap

```js
nv.sliceType = 3                        // 0=Axial, 1=Coronal, 2=Sagittal, 3=Multi, 4=Render
nv.setVolume(0, { colormap: 'hot' })    // apply colormap to first volume
```

### Configuration options

Pass options to the constructor to customize the viewer:

```js
const nv = new NiiVue({
  isColorbarVisible: true,
  backgroundColor: [0, 0, 0, 1],
  clipPlaneColor: [1, 1, 1, 0.5],
})
```

### Migration (rc)

`DecodedChunkStats` (`ChunkStreamDetail.decoded`) is now `ByteLruStats`, which adds `evictedBytes`. `ByteLru<K, V>`, the byte-bounded LRU behind the decoded-chunk tier and the slide tile cache, is exported, and replaces nv-ext-tile's `ByteLruCache`.

Unused slide and streaming options were removed:

- `NVSlideSpatialTransform`, `NVSlideOptions.spatialTransform`, `NVSlide.spatialTransform` and `setSpatialTransform` are gone. Nothing read them; place a slide in world space with `setSlidePlane`'s `pixelToWorld`.
- `createSlideView` no longer takes `renderer`, `ownsSlide` or `signal`. The view makes and destroys its own renderer and always disposes the slide it releases (`setSlide`, `destroy`). To cancel a start, destroy the view once it resolves.
- `loadChunkedVolume` no longer takes `focusBounds` (pass them to `NVChunkedVolume.setFocus(frac, bounds)`), `retryAttempts` (always 3), `frameStagingBytes` (64 MiB) or `readoutBytes` (384 MiB).

### Testing

The package includes a unit test suite for non-rendering logic, including a headless controller (loading, documents, events), using the [Bun test runner](https://bun.sh/docs/cli/test). Tests are co-located with source files as `*.test.ts`. Rendering, Workers and pointer input are covered by Playwright specs in `e2e/` (see `notes/agents/testing.md`).

```bash
bun test                # Run all tests with coverage
bun test src/drawing/   # Run tests in a specific directory
bun test --watch        # Watch mode
```

Coverage is enabled by default (configured in `bunfig.toml`) and outputs both a console summary and an `lcov` report to `coverage/`. Tested modules include:

- **Drawing tools** — RLE codec, pen/line/flood-fill, undo stack
- **Annotations** — undo/redo, point-in-polygon, slice projection, shape selection
- **Math/transforms** — vox↔mm conversions, spherical coordinates, slice plane equations
- **Volume utilities** — intensity range calculation, NIfTI header creation, voxel lookup, reorientation
- **Colormaps** — LUT generation, label colormap construction
- **Mesh I/O** — STL/OBJ writers, STL/OFF readers (roundtrip tests)

To run tests via Nx from the monorepo root:

```bash
bunx nx test niivue
```

### Architecture

The codebase is written in **TypeScript** and follows an MVC pattern with dual rendering backends (WebGPU and WebGL2). See [AGENTS.md](AGENTS.md) for the package's rules and code style, and [notes/agents/](notes/agents/) for architecture and the other areas in detail.

### Dependencies

- [nifti-reader-js](https://github.com/rii-mango/NIFTI-Reader-JS) — NIfTI file parsing
- [gl-matrix](https://glmatrix.net/) — Vector/matrix math (vec3, vec4, mat3, mat4)
- [cbor-x](https://github.com/nicolo-ribaudo/cbor-x) — CBOR encoding/decoding for document save/load and ITK-Wasm (.iwi.cbor) format support
